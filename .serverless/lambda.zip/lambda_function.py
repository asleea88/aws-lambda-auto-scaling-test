import time


def handler(event, context):
    print('Lambda auto-sacaling test')
    time.sleep(1)
